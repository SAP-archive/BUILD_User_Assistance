var TopicFiles = [ 
"0693592c3a614d85bb1a456a515be8be.html",
"1aa707dbf69b425fb9437703ef59b448.html",
"200bbb40aa4f449a81440a4244e382c5.html",
"d1a75c9af7cd4565aaa28fb7ed88b9b2.html",
"disclaimer.html",
"f310f001528e40f0abab71c9016a78b3.html",
];

var TopicTitles = [ 
"View Audit Log",
"Manage Users",
"First Steps for Administrators",
"Admin Console",
"Important Disclaimers and Legal Information",
"Set Domain Access",
];

var TopicDescriptions = [ 
"BUILD Admins can use the Admin Console to view and download user audit log files.",
"BUILD Admins can use the Admin Console to view and delete users, change roles.",
"As a BUILD Administrator, you need to perform these initial steps before others can use the system.",
"The BUILD Admin console allows the BUILD Admin to manage users, domains, and view audit logs.",
"",
"BUILD Admin can add domains and assign roles and permissions to each domain. Then users from these domains can be assigned roles and access BUILD.",
];

